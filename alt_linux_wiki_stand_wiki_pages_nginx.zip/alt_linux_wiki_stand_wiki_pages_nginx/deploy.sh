#!/bin/bash
set -e

SITE_DIR="/var/www/aes-wiki"
CONF_SRC="nginx/aes-wiki.conf"
CONF_DST="/etc/nginx/conf.d/aes-wiki.conf"

mkdir -p "$SITE_DIR"
cp -r site/* "$SITE_DIR/"
cp "$CONF_SRC" "$CONF_DST"

nginx -t
systemctl reload nginx

echo "Готово. Сайт размещён в $SITE_DIR"
