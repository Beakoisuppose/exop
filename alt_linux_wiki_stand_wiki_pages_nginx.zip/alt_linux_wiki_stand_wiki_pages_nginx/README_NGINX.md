# Размещение на Nginx

```bash
apt-get update
apt-get install -y nginx unzip
unzip alt_linux_wiki_stand_wiki_pages_nginx.zip
cd alt_linux_wiki_stand_wiki_pages_nginx
bash deploy.sh
```

Проверка:

```bash
nginx -t
systemctl status nginx --no-pager | head -n 10
curl -I http://localhost
```
