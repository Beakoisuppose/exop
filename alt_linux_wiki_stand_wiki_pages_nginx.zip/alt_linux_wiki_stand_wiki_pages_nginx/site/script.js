
const pageLinks = [...document.querySelectorAll('[data-page-link]')];
const articles = [...document.querySelectorAll('.wiki-article')];
const sidebarToggle = document.querySelector('#sidebarToggle');
const searchInput = document.querySelector('#searchInput');

function normalize(value) {
  return (value || '').toLowerCase().replace(/ё/g, 'е').trim();
}

function showPage(pageId) {
  const ids = articles.map(a => a.id.replace('page-', ''));
  const id = ids.includes(pageId) ? pageId : 'main';

  articles.forEach(article => {
    article.classList.toggle('active', article.id === `page-${id}`);
  });

  pageLinks.forEach(link => {
    link.classList.toggle('active', link.dataset.pageLink === id);
  });

  const activeArticle = document.querySelector(`#page-${id}`);
  const title = activeArticle?.dataset.title || 'ALT Linux Wiki';
  document.title = `${title} — ALT Linux Wiki`;
  window.scrollTo({ top: 0, behavior: 'instant' });
}

function routeFromHash() {
  const id = location.hash.replace('#', '') || 'main';
  showPage(id);
}

window.addEventListener('hashchange', routeFromHash);
routeFromHash();

sidebarToggle?.addEventListener('click', () => {
  document.body.classList.toggle('sidebar-hidden');
  localStorage.setItem('sidebar-hidden', document.body.classList.contains('sidebar-hidden') ? '1' : '0');
});

if (localStorage.getItem('sidebar-hidden') === '1') {
  document.body.classList.add('sidebar-hidden');
}

document.querySelectorAll('.copy').forEach(button => {
  button.addEventListener('click', async () => {
    const code = button.parentElement.querySelector('code')?.innerText || '';
    try {
      await navigator.clipboard.writeText(code);
      const old = button.textContent;
      button.textContent = 'Скопировано';
      setTimeout(() => button.textContent = old, 1200);
    } catch {
      const range = document.createRange();
      range.selectNodeContents(button.parentElement.querySelector('code'));
      const selection = window.getSelection();
      selection.removeAllRanges();
      selection.addRange(range);
      button.textContent = 'Ctrl+C';
    }
  });
});

searchInput?.addEventListener('input', () => {
  const q = normalize(searchInput.value);
  pageLinks.forEach(link => {
    const matched = !q || normalize(link.textContent).includes(q);
    link.classList.toggle('hidden-by-search', !matched);
  });
});
